﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Customer.Entities;
using Customer.Exceptions;
using Customer.DataAccessLayer;

namespace Customer.BusinessLayer
{
    public class CustomerBL
    {
        private static bool ValidateCust(Customers cust)
        {
            StringBuilder sb = new StringBuilder();

            bool validCust = true;

 
            if (cust.CustName == string.Empty)
            {
                validCust = false;
                sb.Append(Environment.NewLine + "Customer Name Required");
            }
            if (cust.CustAddress == string.Empty)
            {
                validCust = false;
                sb.Append(Environment.NewLine + "Customer Name Required");
            }
            if (cust.CustLandmark == string.Empty)
            {
                validCust = false;
                sb.Append(Environment.NewLine + "Landmark Required");
            }
            if (cust.CustPincode.ToString().Length != 6)
            {
                validCust = false;
                sb.Append(Environment.NewLine + "Pincode should be 6 Digit.");
            }
            if (cust.CustContactNo.ToString().Length != 10)
            {
                validCust = false;
                sb.Append(Environment.NewLine + " Enter Phone Number of 10 digits");
            }
           


            if (validCust == false)
            {
                throw new CustomerException(sb.ToString());
            }

            return validCust;

        }

        public static bool AddCustBL(Customers cust)
        {
            bool custAdded = false;

            try
            {
                if (ValidateCust(cust))
                {
                    CustomerDAL custDAL = new CustomerDAL();
                    custAdded = custDAL.InsertDAL(cust);
                }
            }
            catch (CustomerException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return custAdded;
        }
    }
}
