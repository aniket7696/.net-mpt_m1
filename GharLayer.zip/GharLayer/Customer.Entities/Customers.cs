﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer.Entities
{
    public class Customers
    {
        public int CustId { get; set; }
        public string CustName { get; set; }
        public string CustAddress { get; set; }
        public string CustLandmark { get; set; }
        public string CustCity { get; set; }
        public string CustPincode { get; set; }
        public string CustContactNo { get; set; }
        public string CustEmail { get; set; }
}
}
