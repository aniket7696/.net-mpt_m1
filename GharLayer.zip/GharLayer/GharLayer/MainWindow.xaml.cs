﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Customer.Entities;
using Customer.Exceptions;
using Customer.DataAccessLayer;
using Customer.BusinessLayer;

namespace GharLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Customers custom = null;
        public MainWindow()
        {
            InitializeComponent();
        }
        private bool IsValid()
        {
            StringBuilder sb = new StringBuilder();

            bool isValid = true;
            if (txtName.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Customer Name cannot be Blank");
            }
            if (txtAddress.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Address cannot be Blank");
            }
            if (txtLandmark.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Landmark cannot be Blank");
            }
            if (txtPincode.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Pincode cannot be Blank");
            }

            if (txtNumber.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Contact No cannot be Blank");
            }
            if (txtCity.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "City cannot be Blank");
            }
            if (txtEmail.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Email cannot be Blank");
            }
            if (isValid == false)
            {
                throw new CustomerException(sb.ToString());
            }

            return isValid;
        }

        private void AddData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool status = false;
                if (IsValid())
                {
                    custom = new Customers();
                    custom.CustName = txtName.Text;
                    custom.CustAddress = txtAddress.Text;
                    custom.CustLandmark = txtLandmark.Text;
                    custom.CustPincode = txtPincode.Text;
                    custom.CustContactNo = txtNumber.Text;
                    custom.CustEmail = txtEmail.Text;
                    custom.CustCity = txtCity.Text;


                    status = CustomerBL.AddCustBL(custom); 
                    
                }
                if (status == true)
                    MessageBox.Show("Inserted");

            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        
    }
}
