﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using Customer.Entities;
using Customer.Exceptions;

namespace Customer.DataAccessLayer
{
    public class CustomerDAL
    {
        SqlConnection conn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public CustomerDAL()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn1"].ConnectionString);
        }
        public bool InsertDAL(Customers cus)
        {
            bool custAdded = false;
            try
            {
                cmd = new SqlCommand("sal_302.USP_CustInsertt", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", cus.CustName);
                cmd.Parameters.AddWithValue("@add", cus.CustAddress);
                cmd.Parameters.AddWithValue("@landmark", cus.CustLandmark);
                cmd.Parameters.AddWithValue("@pincode", cus.CustPincode);
                cmd.Parameters.AddWithValue("@city", cus.CustCity);
                cmd.Parameters.AddWithValue("@number", cus.CustContactNo);
                cmd.Parameters.AddWithValue("@email", cus.CustEmail);

                conn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                    custAdded = true;
            }
            catch (Exception ex)
            {
                throw new CustomerException(ex.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
            return custAdded;
        }

        
    }
}
